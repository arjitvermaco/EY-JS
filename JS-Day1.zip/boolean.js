// Boolean Data type

//let x = "false"; // string

let x = false;
let y = new Boolean(true);

console.log(Boolean(10 > 9));