// Assignment Operator =

let x = 10; // assign the value 5 to x
let y = 10; // assign the value 10 to y
let z= x + y; // assign the value 15 to z(5+10)


// Addition operator +

var a = 10;
var b = 15;
var c = a+b;


let greeting = "Good";
let time = "Afternoon";
let finalGreeting = greeting + " " + time;
console.log(finalGreeting);


// Multiplication *

var a = 10;
var b = 15;
var c = a*b;

// x+=y // this means x=x+y

// x+=y;
// console.log("Value of x is :",x);

//x-=y // this means x = x-y

// x-=y;
// console.log("Value of x is:",x)

// x++ // x = x+1
//x-- // x=x-1

// ** is exponential operator
console.log(x**3);



//  / division

console.log(16/4);   // 4

// % (Division Remainder)

console.log(18%4); // 0
