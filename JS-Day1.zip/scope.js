let x = 10;


if(x<20){
    var y = 20;
    console.log(y);

}

console.log(y);
